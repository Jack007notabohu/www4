<?php
$idtele = '2078384341'; //ID telegram kamu
$idbot = '5536902672:AAEKtxI4uYVYPrWeYHgMsGvYrXsmr1LGb5g'; //ID bot telegram kamu
?>